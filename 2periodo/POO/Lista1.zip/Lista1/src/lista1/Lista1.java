package lista1;

import javax.swing.JOptionPane;

public class Lista1 {
    
    public static void exe1(){
        int x,y;
        x=Integer.parseInt(JOptionPane.showInputDialog("Digite um número inteiro:"));
        y=Integer.parseInt(JOptionPane.showInputDialog("Digite outro número inteiro:"));
        if(x>y)
            JOptionPane.showMessageDialog(null,"O número "+x+" é maior que o número "+y);
        else if(x<y)
            JOptionPane.showMessageDialog(null,"O número "+x+" é menor que o número "+y);
        else
            JOptionPane.showMessageDialog(null,"O número "+x+" é igual que o número "+y);            
    }
    
    public static void main(String[] args) {
        int op;
        
        do{
            op = Integer.parseInt(JOptionPane.showInputDialog("    M E N U\n\n1- Compara Números\n2- Equação do Segundo Grau\n3- \n\n\n17- SAIR\n\nDIGITE A OPÇÃO:"));
            switch(op){
                case 1: exe1();
                case 2:
                // até case 16
            }
        }while(op!=17);
        
    }
    
}
